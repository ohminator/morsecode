/**
 * Die Klasse Morsecode wurde automatisch erstellt: 
 * 
 * @author 
 * @version 8.6.2026
 */

import sum.komponenten.*;
import sum.werkzeuge.*;
import sum.ereignis.*;

public class Morsecodeanwendung extends EBAnwendung
{
    // Objekte
    private Zeichenbereich hatZeichenbereich1;
    private Zeichenbereich hatZeichenbereich2;
    private Zeichenbereich hatZeichenbereich3;
    private Knopf hatKnopf1;
    private Knopf hatKnopf2;
    private Etikett hatEtikettKeineLeerzeichen;

    // Attribute

/**
 * Konstruktor
 */
    public Morsecodeanwendung()
    {
        //Initialisierung der Oberklasse
        super(1735, 1007);

        hatZeichenbereich1 = new Zeichenbereich(48, 8, 200, 300, "");
        hatZeichenbereich2 = new Zeichenbereich(349, 8, 200, 300, "");
        hatZeichenbereich3 = new Zeichenbereich(648, 8, 200, 300, "");
        hatKnopf1 = new Knopf(248, 166, 100, 25, "Knopf 1");
        hatKnopf1.setzeBearbeiterGeklickt("hatKnopf1Geklickt");
        hatKnopf2 = new Knopf(547, 167, 100, 25, "Knopf 2");
        hatKnopf2.setzeBearbeiterGeklickt("hatKnopf2Geklickt");
        hatEtikettKeineLeerzeichen = new Etikett(48, 325, 584, 25, "Keine Leerzeichen ");
        // Ausrichtung
        hatEtikettKeineLeerzeichen.setzeAusrichtung(Ausrichtung.LINKS);
    }

/**
 * Vorher: Ereignis GeklicktvonhatKnopf1 fand statt.
 * Nachher: (schreiben Sie, was in dieser Methode ausgefuehrt wird)
 */
    public void hatKnopf1Geklickt()
    {
        //    Schreiben Sie hier den Text ihres Dienstes
    }

/**
 * Vorher: Ereignis GeklicktvonhatKnopf2 fand statt.
 * Nachher: (schreiben Sie, was in dieser Methode ausgefuehrt wird)
 */
    public void hatKnopf2Geklickt()
    {
        //    Schreiben Sie hier den Text ihres Dienstes
    }

}
