/**
 * Dokumentation der Klasse "Zeichenklasse".
 * Bettet den einfachen Datentyp Zeichen in ein Objekt ein.
 */
public class Zeichenklasse {
    
    // Attribut zum Speichern des eigentlichen Zeichens 
    private char zZeichen;

    /**
     * Auftrag init(pZeichen:Zeichen) 
     * nachher: Das Objekt der Klasse Zeichenklasse existiert und ist initialisiert.
     */
    public Zeichenklasse(char pZeichen) {
        zZeichen = pZeichen;
    }

    /**
     * Anfrage zeichen:Zeichen 
     * nachher: Diese Anfrage liefert das Zeichen.
     */
    public char zeichen() {
        return zZeichen;
    }

    /**
     * Auftrag gibFrei 
     * nachher: Das Objekt existiert nicht mehr.
     */
    public void gibFrei() {
        // In Java kümmert sich der Garbage Collector um die Speicherfreigabe, 
        // wir können aber den Wert "leeren", um Fehler abzufangen.
        zZeichen = '\0'; 
    }
}