import sum.komponenten.*;
import sum.werkzeuge.*;
import sum.ereignis.*;

public class Morsecodeanwendung extends EBAnwendung
{
    // Objekte
    private Zeichenbereich hatZeichenbereich1;
    private Zeichenbereich hatZeichenbereich2;
    private Zeichenbereich hatZeichenbereich3;
    private Knopf hatKnopf1;
    private Knopf hatKnopf2;
    private Etikett hatEtikettKeineLeerzeichen;
    private Zeichenbaum morseBaum;

    // Attribute

    /**
     * Konstruktor
     */
    public Morsecodeanwendung()
    {
        //Initialisierung der Oberklasse
        super(1000, 400);
        this.baueBaum();
        hatZeichenbereich1 = new Zeichenbereich(48, 8, 200, 300, "");
        hatZeichenbereich2 = new Zeichenbereich(349, 8, 200, 300, "");
        hatZeichenbereich3 = new Zeichenbereich(648, 8, 200, 300, "");
        hatKnopf1 = new Knopf(248, 166, 100, 25, "Knopf 1");
        hatKnopf1.setzeBearbeiterGeklickt("hatKnopf1Geklickt");
        hatKnopf2 = new Knopf(547, 167, 100, 25, "Knopf 2");
        hatKnopf2.setzeBearbeiterGeklickt("hatKnopf2Geklickt");
        hatEtikettKeineLeerzeichen = new Etikett(48, 325, 584, 25, "Keine Leerzeichen ");
        // Ausrichtung
        hatEtikettKeineLeerzeichen.setzeAusrichtung(Ausrichtung.LINKS);
    }
    
    /**
     * Vorher: Ereignis GeklicktvonhatKnopf1 fand statt.
     * Nachher: (schreiben Sie, was in dieser Methode ausgefuehrt wird)
     */
     public void hatKnopf1Geklickt()
    {
        hatZeichenbereich2.loescheAlles();
        hatZeichenbereich2.haengeAn(decodiereZeichen(hatZeichenbereich1.inhaltAlsText()));
        System.out.println(decodiereZeichen(hatZeichenbereich1.inhaltAlsText()));
    }
    
    /**
     * Vorher: Ereignis GeklicktvonhatKnopf2 fand statt.
     * Nachher: (schreiben Sie, was in dieser Methode ausgefuehrt wird)
     */
     public void hatKnopf2Geklickt()
    {
        hatZeichenbereich3.loescheAlles();
        hatZeichenbereich3.haengeAn(decodiereZeichen(hatZeichenbereich2.inhaltAlsText()));
        System.out.println(decodiereZeichen(hatZeichenbereich2.inhaltAlsText()));
    }
    
    private void baueBaum() {
        // 1. Die Wurzel erstellen (enthält ein leeres Zeichen als Startpunkt)
        morseBaum = new Zeichenbaum(new Zeichenklasse(' '));

        // ==========================================
        // LINKER HAUPTTEILBAUM (Start mit Punkt '.')
        // ==========================================
        
        // Ebene 4 (Blätter unter S und U)
        Zeichenbaum baumH = new Zeichenbaum(new Zeichenklasse('H'));
        Zeichenbaum baumV = new Zeichenbaum(new Zeichenklasse('V'));
        Zeichenbaum baumF = new Zeichenbaum(new Zeichenklasse('F'));
        Zeichenbaum baumUe = new Zeichenbaum(new Zeichenklasse('Ü'));

        // Ebene 3 (Knoten S und U zusammenbauen)
        Zeichenbaum baumS = new Zeichenbaum(new Zeichenklasse('S'));
        baumS.haengeLinksAn(baumH);
        baumS.haengeRechtsAn(baumV);

        Zeichenbaum baumU = new Zeichenbaum(new Zeichenklasse('U'));
        baumU.haengeLinksAn(baumF);
        baumU.haengeRechtsAn(baumUe);

        // Ebene 4 (Blätter unter R und W)
        Zeichenbaum baumL = new Zeichenbaum(new Zeichenklasse('L'));
        Zeichenbaum baumAe = new Zeichenbaum(new Zeichenklasse('Ä'));
        Zeichenbaum baumP = new Zeichenbaum(new Zeichenklasse('P'));
        Zeichenbaum baumJ = new Zeichenbaum(new Zeichenklasse('J'));

        // Ebene 3 (Knoten R und W zusammenbauen)
        Zeichenbaum baumR = new Zeichenbaum(new Zeichenklasse('R'));
        baumR.haengeLinksAn(baumL);
        baumR.haengeRechtsAn(baumAe);

        Zeichenbaum baumW = new Zeichenbaum(new Zeichenklasse('W'));
        baumW.haengeLinksAn(baumP);
        baumW.haengeRechtsAn(baumJ);

        // Ebene 2 (Knoten I und A zusammenbauen)
        Zeichenbaum baumI = new Zeichenbaum(new Zeichenklasse('I'));
        baumI.haengeLinksAn(baumS);
        baumI.haengeRechtsAn(baumU);

        Zeichenbaum baumA = new Zeichenbaum(new Zeichenklasse('A'));
        baumA.haengeLinksAn(baumR);
        baumA.haengeRechtsAn(baumW);

        // Ebene 1 (Knoten E zusammenbauen)
        Zeichenbaum baumE = new Zeichenbaum(new Zeichenklasse('E'));
        baumE.haengeLinksAn(baumI);
        baumE.haengeRechtsAn(baumA);


        // ==========================================
        // RECHTER HAUPTTEILBAUM (Start mit Strich '-')
        // ==========================================
        
        // Ebene 4 (Blätter unter D und K)
        Zeichenbaum baumB = new Zeichenbaum(new Zeichenklasse('B'));
        Zeichenbaum baumX = new Zeichenbaum(new Zeichenklasse('X'));
        Zeichenbaum baumC = new Zeichenbaum(new Zeichenklasse('C'));
        Zeichenbaum baumY = new Zeichenbaum(new Zeichenklasse('Y'));

        // Ebene 3 (Knoten D und K zusammenbauen)
        Zeichenbaum baumD = new Zeichenbaum(new Zeichenklasse('D'));
        baumD.haengeLinksAn(baumB);
        baumD.haengeRechtsAn(baumX);

        Zeichenbaum baumK = new Zeichenbaum(new Zeichenklasse('K'));
        baumK.haengeLinksAn(baumC);
        baumK.haengeRechtsAn(baumY);

        // Ebene 4 (Blätter unter G und O)
        Zeichenbaum baumQ = new Zeichenbaum(new Zeichenklasse('Q'));
        Zeichenbaum baumZ = new Zeichenbaum(new Zeichenklasse('Z'));
        Zeichenbaum baumOe = new Zeichenbaum(new Zeichenklasse('Ö'));
        // 'CH' wird als einzelnes Zeichen in der Zeichenklasse abgebildet (vereinfacht als '*' oder 'C')
        // Hier nutzen wir ein einzelnes char-Symbol oder passen es an, wir nehmen 'CH' als logische Repräsentation
        // Da char nur ein Zeichen erlaubt, nutzen wir hier das Zeichen '#' für CH oder ein Stellvertreter-Symbol.
        Zeichenbaum baumCh = new Zeichenbaum(new Zeichenklasse('*')); 

        // Ebene 3 (Knoten G und O zusammenbauen)
        Zeichenbaum baumG = new Zeichenbaum(new Zeichenklasse('G'));
        baumG.haengeLinksAn(baumQ);
        baumG.haengeRechtsAn(baumZ);

        Zeichenbaum baumO = new Zeichenbaum(new Zeichenklasse('O'));
        baumO.haengeLinksAn(baumOe);
        baumO.haengeRechtsAn(baumCh);

        // Ebene 2 (Knoten N und M zusammenbauen)
        Zeichenbaum baumN = new Zeichenbaum(new Zeichenklasse('N'));
        baumN.haengeLinksAn(baumD);
        baumN.haengeRechtsAn(baumK);

        Zeichenbaum baumM = new Zeichenbaum(new Zeichenklasse('M'));
        baumM.haengeLinksAn(baumG);
        baumM.haengeRechtsAn(baumO);

        // Ebene 1 (Knoten T zusammenbauen)
        Zeichenbaum baumT = new Zeichenbaum(new Zeichenklasse('T'));
        baumT.haengeLinksAn(baumN);
        baumT.haengeRechtsAn(baumM);


        // ==========================================
        // DIE HOCHZEIT AN DER WURZEL
        // ==========================================
        morseBaum.haengeLinksAn(baumE);
        morseBaum.haengeRechtsAn(baumT);
    }
    
    public char decodiereZeichen(String pMorseCode) {
        // Wir starten die Suche immer ganz oben an der Wurzel
        Zeichenbaum lAktuellerKnoten = this.morseBaum;
        
        // Jedes Symbol im Morsecode steuert den Weg nach links oder rechts
        for (int i = 0; i < pMorseCode.length(); i++) {
            char lSymbol = pMorseCode.charAt(i);
            
            if (lAktuellerKnoten.istLeer()) {
                return '?'; // Fehler: Der Pfad existiert im Baum nicht
            }
            
            if (lSymbol == '.') {
                // Punkt bedeutet: Geh in den linken Teilbaum
                lAktuellerKnoten = lAktuellerKnoten.linkerTeilbaum();
            } else if (lSymbol == '-') {
                // Strich bedeutet: Geh in den rechten Teilbaum
                lAktuellerKnoten = lAktuellerKnoten.rechterTeilbaum();
            }
        }
        
        // Am Ende des Pfades angekommen, fragen wir den Inhalt des Knotens ab
        if (!lAktuellerKnoten.istLeer() && lAktuellerKnoten.wurzelInhalt() != null) {
            return lAktuellerKnoten.wurzelInhalt().zeichen();
        } else {
            return '?';
        }
    }
}
