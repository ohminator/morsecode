public class SuMProgramm
{
    public static void main(String args[])
    {
        Morsecodeanwendung hatMorsecode = new Morsecodeanwendung();
        hatMorsecode.fuehreAus();
    }

}
