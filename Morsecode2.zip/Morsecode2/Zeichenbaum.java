/**
 * Dokumentation der Klasse "Zeichenbaum".
 * Ein Zeichenbaum ist ein Binärbaum, der Objekte der Klasse Zeichenklasse 
 * als Knoteninhalte hat.
 */
public class Zeichenbaum {
    
    // Eine Wurzel hat einen Inhalt und verweist auf zwei weitere Bäume 
    private Zeichenklasse zWurzelInhalt;
    private Zeichenbaum zLinkerTeilbaum;
    private Zeichenbaum zRechterTeilbaum;

    /**
     * Auftrag init 
     * nachher: Ein leerer Baum existiert.
     */
    public Zeichenbaum() {
        zWurzelInhalt = null;
        zLinkerTeilbaum = null;
        zRechterTeilbaum = null;
    }

    /**
     * Auftrag init(pInhalt: Zeichenklasse) 
     * nachher: Der Zeichenbaum existiert und hat eine Wurzel mit dem übergebenen 
     * Inhalt und zwei leeren Teilbäumen.
     */
    public Zeichenbaum(Zeichenklasse pInhalt) {
        zWurzelInhalt = pInhalt;
        // Erschaffe zwei leere Bäume als Blätter
        zLinkerTeilbaum = new Zeichenbaum();
        zRechterTeilbaum = new Zeichenbaum();
    }

    /**
     * Auftrag haengeRechtsAn(pBaum:Zeichenbaum)
     * vorher: Der Zeichenbaum ist nicht leer.
     * nachher: Die Wurzel hat den übergebenen Baum als rechten Teilbaum.
     */
    public void haengeRechtsAn(Zeichenbaum pBaum) {
        if (!this.istLeer()) {
            zRechterTeilbaum = pBaum;
        }
    }

    /**
     * Auftrag haengeLinksAn(pBaum:Zeichenbaum)
     * vorher: Der Zeichenbaum ist nicht leer.
     * nachher: Die Wurzel hat den übergebenen Baum als linken Teilbaum.
     */
    public void haengeLinksAn(Zeichenbaum pBaum) {
        if (!this.istLeer()) {
            zLinkerTeilbaum = pBaum;
        }
    }

    /**
     * Anfrage wurzelInhalt: Zeichenklasse 
     * vorher: Der Binärbaum ist nicht leer.
     * nachher: Diese Anfrage liefert den Inhalt der Wurzel des Binärbaums.
     */
    public Zeichenklasse wurzelInhalt() {
        return zWurzelInhalt;
    }

    /**
     * Anfrage linkerTeilbaum:Zeichenbaum 
     * vorher: Der Zeichenbaum ist nicht leer.
     * nachher: Liefert den linken Teilbaum der Wurzel.
     */
    public Zeichenbaum linkerTeilbaum() {
        return zLinkerTeilbaum;
    }

    /**
     * Anfrage rechterTeilbaum:Zeichenbaum 
     * vorher: Der Zeichenbaum ist nicht leer.
     * nachher: Liefert den rechten Teilbaum der Wurzel.
     */
    public Zeichenbaum rechterTeilbaum() {
        return zRechterTeilbaum;
    }

    /**
     * Anfrage istLeer: Wahrheitswert 
     * nachher: Liefert "wahr", wenn der Zeichenbaum leer ist.
     */
    public boolean istLeer() {
        return (zWurzelInhalt == null);
    }

    /**
     * Anfrage teilbaeumeLeer: Wahrheitswert 
     * nachher: Liefert "wahr", wenn beide Teilbäume der Wurzel leer sind, 
     * die Wurzel also ein Blatt ist.
     */
    public boolean teilbaeumeLeer() {
        if (this.istLeer()) return false;
        return (zLinkerTeilbaum.istLeer() && zRechterTeilbaum.istLeer());
    }
}