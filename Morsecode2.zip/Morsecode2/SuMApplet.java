import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;

public class SuMApplet extends Applet
{
    public SuMApplet()
    {
        Morsecodeanwendung hatMorsecode = new Morsecodeanwendung();
        hatMorsecode.fuehreAus();
    }

}
