/**
 * Die Klasse MorseDecoder baut den vollständigen Morsebaum auf
 * und stellt eine Methode bereit, um Morse-Code-Zeichenketten
 * (bestehend aus Punkten und Strichen) in lesbare Buchstaben zu decodieren.
 */
public class MorseDecoder {
    
    // Die Wurzel unseres binären Zeichenbaums
    private Zeichenbaum morseBaum;

    /**
     * Konstruktor: Initialisiert den Decoder und baut den gesamten Baum auf.
     */
    public MorseDecoder() {
        this.baueBaum();
    }

    /**
     * Private Hilfsmethode, die den gesamten Morsebaum Ebene für Ebene 
     * von unten nach oben (oder über gezielte Teilbäume) zusammensetzt.
     */
    private void baueBaum() {
        // 1. Die Wurzel erstellen (enthält ein leeres Zeichen als Startpunkt)
        morseBaum = new Zeichenbaum(new Zeichenklasse(' '));

        // ==========================================
        // LINKER HAUPTTEILBAUM (Start mit Punkt '.')
        // ==========================================
        
        // Ebene 4 (Blätter unter S und U)
        Zeichenbaum baumH = new Zeichenbaum(new Zeichenklasse('H'));
        Zeichenbaum baumV = new Zeichenbaum(new Zeichenklasse('V'));
        Zeichenbaum baumF = new Zeichenbaum(new Zeichenklasse('F'));
        Zeichenbaum baumUe = new Zeichenbaum(new Zeichenklasse('Ü'));

        // Ebene 3 (Knoten S und U zusammenbauen)
        Zeichenbaum baumS = new Zeichenbaum(new Zeichenklasse('S'));
        baumS.haengeLinksAn(baumH);
        baumS.haengeRechtsAn(baumV);

        Zeichenbaum baumU = new Zeichenbaum(new Zeichenklasse('U'));
        baumU.haengeLinksAn(baumF);
        baumU.haengeRechtsAn(baumUe);

        // Ebene 4 (Blätter unter R und W)
        Zeichenbaum baumL = new Zeichenbaum(new Zeichenklasse('L'));
        Zeichenbaum baumAe = new Zeichenbaum(new Zeichenklasse('Ä'));
        Zeichenbaum baumP = new Zeichenbaum(new Zeichenklasse('P'));
        Zeichenbaum baumJ = new Zeichenbaum(new Zeichenklasse('J'));

        // Ebene 3 (Knoten R und W zusammenbauen)
        Zeichenbaum baumR = new Zeichenbaum(new Zeichenklasse('R'));
        baumR.haengeLinksAn(baumL);
        baumR.haengeRechtsAn(baumAe);

        Zeichenbaum baumW = new Zeichenbaum(new Zeichenklasse('W'));
        baumW.haengeLinksAn(baumP);
        baumW.haengeRechtsAn(baumJ);

        // Ebene 2 (Knoten I und A zusammenbauen)
        Zeichenbaum baumI = new Zeichenbaum(new Zeichenklasse('I'));
        baumI.haengeLinksAn(baumS);
        baumI.haengeRechtsAn(baumU);

        Zeichenbaum baumA = new Zeichenbaum(new Zeichenklasse('A'));
        baumA.haengeLinksAn(baumR);
        baumA.haengeRechtsAn(baumW);

        // Ebene 1 (Knoten E zusammenbauen)
        Zeichenbaum baumE = new Zeichenbaum(new Zeichenklasse('E'));
        baumE.haengeLinksAn(baumI);
        baumE.haengeRechtsAn(baumA);


        // ==========================================
        // RECHTER HAUPTTEILBAUM (Start mit Strich '-')
        // ==========================================
        
        // Ebene 4 (Blätter unter D und K)
        Zeichenbaum baumB = new Zeichenbaum(new Zeichenklasse('B'));
        Zeichenbaum baumX = new Zeichenbaum(new Zeichenklasse('X'));
        Zeichenbaum baumC = new Zeichenbaum(new Zeichenklasse('C'));
        Zeichenbaum baumY = new Zeichenbaum(new Zeichenklasse('Y'));

        // Ebene 3 (Knoten D und K zusammenbauen)
        Zeichenbaum baumD = new Zeichenbaum(new Zeichenklasse('D'));
        baumD.haengeLinksAn(baumB);
        baumD.haengeRechtsAn(baumX);

        Zeichenbaum baumK = new Zeichenbaum(new Zeichenklasse('K'));
        baumK.haengeLinksAn(baumC);
        baumK.haengeRechtsAn(baumY);

        // Ebene 4 (Blätter unter G und O)
        Zeichenbaum baumQ = new Zeichenbaum(new Zeichenklasse('Q'));
        Zeichenbaum baumZ = new Zeichenbaum(new Zeichenklasse('Z'));
        Zeichenbaum baumOe = new Zeichenbaum(new Zeichenklasse('Ö'));
        // 'CH' wird als einzelnes Zeichen in der Zeichenklasse abgebildet (vereinfacht als '*' oder 'C')
        // Hier nutzen wir ein einzelnes char-Symbol oder passen es an, wir nehmen 'CH' als logische Repräsentation
        // Da char nur ein Zeichen erlaubt, nutzen wir hier das Zeichen '#' für CH oder ein Stellvertreter-Symbol.
        Zeichenbaum baumCh = new Zeichenbaum(new Zeichenklasse('*')); 

        // Ebene 3 (Knoten G und O zusammenbauen)
        Zeichenbaum baumG = new Zeichenbaum(new Zeichenklasse('G'));
        baumG.haengeLinksAn(baumQ);
        baumG.haengeRechtsAn(baumZ);

        Zeichenbaum baumO = new Zeichenbaum(new Zeichenklasse('O'));
        baumO.haengeLinksAn(baumOe);
        baumO.haengeRechtsAn(baumCh);

        // Ebene 2 (Knoten N und M zusammenbauen)
        Zeichenbaum baumN = new Zeichenbaum(new Zeichenklasse('N'));
        baumN.haengeLinksAn(baumD);
        baumN.haengeRechtsAn(baumK);

        Zeichenbaum baumM = new Zeichenbaum(new Zeichenklasse('M'));
        baumM.haengeLinksAn(baumG);
        baumM.haengeRechtsAn(baumO);

        // Ebene 1 (Knoten T zusammenbauen)
        Zeichenbaum baumT = new Zeichenbaum(new Zeichenklasse('T'));
        baumT.haengeLinksAn(baumN);
        baumT.haengeRechtsAn(baumM);


        // ==========================================
        // DIE HOCHZEIT AN DER WURZEL
        // ==========================================
        morseBaum.haengeLinksAn(baumE);
        morseBaum.haengeRechtsAn(baumT);
    }

    /**
     * Decodiert ein einzelnes Morsezeichen (z.B. "...-") in den echten Buchstaben.
     * * @param pMorseCode Eine Zeichenkette aus Punkten und Strichen.
     * @return Der decodierte Buchstabe als char.
     */
    public char decodiereZeichen(String pMorseCode) {
        // Wir starten die Suche immer ganz oben an der Wurzel
        Zeichenbaum lAktuellerKnoten = this.morseBaum;
        
        // Jedes Symbol im Morsecode steuert den Weg nach links oder rechts
        for (int i = 0; i < pMorseCode.length(); i++) {
            char lSymbol = pMorseCode.charAt(i);
            
            if (lAktuellerKnoten.istLeer()) {
                return '?'; // Fehler: Der Pfad existiert im Baum nicht
            }
            
            if (lSymbol == '.') {
                // Punkt bedeutet: Geh in den linken Teilbaum
                lAktuellerKnoten = lAktuellerKnoten.linkerTeilbaum();
            } else if (lSymbol == '-') {
                // Strich bedeutet: Geh in den rechten Teilbaum
                lAktuellerKnoten = lAktuellerKnoten.rechterTeilbaum();
            }
        }
        
        // Am Ende des Pfades angekommen, fragen wir den Inhalt des Knotens ab
        if (!lAktuellerKnoten.istLeer() && lAktuellerKnoten.wurzelInhalt() != null) {
            return lAktuellerKnoten.wurzelInhalt().zeichen();
        } else {
            return '?';
        }
    }
}